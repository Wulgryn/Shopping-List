﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace SL.UI
{
	public static class ObservableCollectionEx
	{
		public static void AddRange<T>(this ObservableCollection<T> col, IEnumerable<T> items)
		{
			if (items is null) return;
			foreach (var i in items) col.Add(i); // egyszerű út: ha akadozik, lásd Reset-es verzió lent
		}

		// Gyorsabb: 1 Reset értesítés (UI teljes újrarajz), nagy listáknál jobb
		public static void ResetWith<T>(this ObservableCollection<T> col, IEnumerable<T> items)
		{
			col.Clear();
			foreach (var i in items) col.Add(i);
			var args = new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset);
			(col as INotifyCollectionChanged)?.GetType()
				.GetMethod("OnCollectionChanged", BindingFlags.Instance | BindingFlags.NonPublic)?
				.Invoke(col, new object[] { args });
		}
	}
}
