using CommunityToolkit.Maui.Views;
using SL.Core;
using SL.UI.Controls;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Threading.Tasks;

namespace SL.UI.Pages;

public partial class SearchPage : ContentPage
{
	ObservableCollection<Product> items = new ObservableCollection<Product>();
	MainPage mp;

	private async void RefreshItems()
	{
		if (!itemSearchResults.IsLoaded) return;
		await Dispatcher.DispatchAsync(() =>
		{
			items.Clear();
			if (ItemSearchBar.Text == "") ProductList.GetItems().ForEach(pl_item => Dispatcher.Dispatch(() => items.Add(pl_item)));
			else ProductList.Search(ItemSearchBar.Text ?? "").ForEach(pl_item => Dispatcher.Dispatch(() => items.Add(pl_item)));
		});

	}
	public SearchPage()
	{
		InitializeComponent();
		Loaded += async (s, e) =>
		{
			await Dispatcher.DispatchAsync(() =>
			{
				ProductList.GetItems().ForEach(pl_item => Dispatcher.Dispatch(() => items.Add(pl_item)));
				itemSearchResults.ItemsSource = items;
			});
		};
		ItemSearchBar.Loaded += (s, e) =>
		{
			//items.Clear();
			//if (ItemSearchBar.Text == "") ProductList.GetItems().ForEach(items.Add);
			//else ProductList.Search(ItemSearchBar.Text ?? "").ForEach(items.Add);
			RefreshItems();
		};
		NavigatedTo += async (s, e) =>
		{
			await Dispatcher.DispatchAsync(() =>
			{
				items.Clear();
				ProductList.GetItems().ForEach(pl_item => Dispatcher.Dispatch(() => items.Add(pl_item)));
				itemSearchResults.ItemsSource = items;
			});
		};
	}

	public SearchPage(MainPage mp) : this()
	{
		this.mp = mp;
	}

	private void ItemSearchBar_TextChanged(object sender, TextChangedEventArgs e)
	{
		items.Clear();
		ProductList.Search(e.NewTextValue).ForEach(items.Add);
		itemSearchResults.ItemsSource = items;
	}

	private void Grid_Focused(object sender, FocusEventArgs e)
	{
		Debug.WriteLine("Focused");
	}

	private async void CreateNewItemBtn_Clicked(object sender, EventArgs e)
	{
		//var value = await this.ShowPopupAsync(new ModifyItemPopup("kezdeti érték")) as string;
		//if (value is not null)
		//{
		//	// OK: felhasználói szöveg a 'value'-ban
		//}
		await Application.Current.MainPage.Navigation.PushAsync(new AddItem(), true);
	}

	private async void modify_item_Clicked(object sender, EventArgs e)
	{
		Product product = (sender as MenuItem).BindingContext as Product;
		string new_name = await DisplayPromptAsync("Név módosítás", $"Eredeti név: \"{product.name}\"", "Mentés", "Mégsem", initialValue: product.name);
		if (string.IsNullOrEmpty(new_name)) return;
		if (ProductList.GetItem(new_name ?? "") is not null)
		{
			await DisplayAlert("Error", "An item with that name already exists.", "OK");
			return;
		}

		Product p = ProductList.GetItem(product.name);
		ProductList.RemoveItem(p.name);
		ProductList.AddItem(new_name, p.prices.FirstOrDefault(-1));
		p.prices.Skip(1).ToList().ForEach(price => ProductList.AddItemPrice(new_name, price));

		RefreshItems();
	}

	private async void modify_item_price_Clicked(object sender, EventArgs e)
	{
		Product product = (sender as MenuItem).BindingContext as Product;
		string new_price = await DisplayPromptAsync("Ár megadás", $"Eredeti ár: {product.last_price} Ft / db-kg", "Mentés", "Mégsem", initialValue: product.last_price.ToString(), keyboard: Keyboard.Numeric);
		if (string.IsNullOrEmpty(new_price)) return;
		
		if(!int.TryParse(new_price, out int new_price_i))
		{
			await DisplayAlert("Error", "Only integers accepted", "OK");
			return;
		}

		ProductList.AddItemPrice(product.name, new_price_i);

		RefreshItems();
	}

	private async void delete_item_Clicked(object sender, EventArgs e)
	{
		Product product = (sender as MenuItem).BindingContext as Product;
		bool delete = await DisplayAlert("Termék törlése", $"Biztosan törölni szeretnéd: \"{product.name}\"", "Igen", "Nem");

		if (!delete) return;

		ProductList.RemoveItem(product.name);

		RefreshItems();
	}

	private async void itemSearchResults_ItemSelected(object sender, SelectedItemChangedEventArgs e)
	{
		Product product = items[e.SelectedItemIndex];
		if (ShoppingList.GetItem(product?.name ?? "") is null) ShoppingList.AddItem(product?.name ?? "ERROR");
		mp.RefreshItems();
		await Navigation.PopAsync(true);
	}
}